// GreenHumble v1.1 Vanilla JS Interactive Engine matching React behavior
document.addEventListener('DOMContentLoaded', () => {
  console.log('GreenHumble v1.1 OVH Vanilla Engine Initialized.');

  // Tab navigation handling
  const navTabs = document.querySelectorAll('.nav-tab');
  navTabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      const page = tab.getAttribute('data-page');
      if (page) {
        window.location.href = '?page=' + page;
      }
    });
  });

  // Audit form submission simulation
  const auditForm = document.getElementById('audit-form');
  if (auditForm) {
    auditForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const urlInput = document.getElementById('audit-url-input');
      if (urlInput && urlInput.value.trim()) {
        const submitBtn = auditForm.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span class="animate-pulse">Analyse IA en cours (Gemini 3.8)...</span>';
        }
        setTimeout(() => {
          alert('Audit Greenwashing & Directive Green Claims terminé avec succès pour : ' + urlInput.value);
          window.location.href = '?page=scans';
        }, 1800);
      } else {
        alert('Veuillez entrer une URL valide.');
      }
    });
  }

  // Print report trigger
  const printBtn = document.getElementById('print-report-btn');
  if (printBtn) {
    printBtn.addEventListener('click', () => {
      window.print();
    });
  }
});
