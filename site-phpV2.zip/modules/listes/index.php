<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-black text-white font-serif">4. Listes de Travail & Cibles Prioritaires</h2>
        <p class="text-xs text-[#A0A0A0]">Organisation des listes de prospection et ciblage sectoriel</p>
      </div>
      <button onclick="alert('Création d\'une liste')" class="px-4 py-2 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">+ Nouvelle Liste</button>
    </div>
    <div class="bg-[#121212] p-6 rounded-2xl border border-white/10 space-y-3">
      <h4 class="font-bold text-white text-sm">Priorité Bilan Carbone & CSRD</h4>
      <p class="text-xs text-[#A0A0A0]">Entreprises cibles prioritaires pour le Diag Décarbon'Action Bpifrance.</p>
      <div class="text-xs font-mono text-[#2A7AE2]">0 élément dans la liste</div>
    </div>
  </div>
</div>