<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <h2 class="text-2xl font-black text-white font-serif">Gestion des Collaborateurs</h2>
    <table class="w-full text-left text-xs text-[#E0E0E0]">
      <thead class="bg-[#121212] text-[#A0A0A0] uppercase font-bold">
        <tr><th class="px-6 py-3">Nom</th><th class="px-6 py-3">Email</th><th class="px-6 py-3">Rôle</th></tr>
      </thead>
      <tbody class="divide-y divide-white/10">
        <tr><td class="px-6 py-4 font-bold text-white">Julien Lavaud</td><td class="px-6 py-4 text-[#A0A0A0]">jul1lavaud@gmail.com</td><td class="px-6 py-4"><span class="px-2 py-0.5 rounded bg-[#2A7AE2]/20 text-[#2A7AE2]">Super Admin</span></td></tr>
      </tbody>
    </table>
  </div>
</div>