<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-black text-white font-serif">5. Groupes de Scanners Sectoriels</h2>
        <p class="text-xs text-[#A0A0A0]">Gestion exclusive des groupes de scan et règles sectorielles</p>
      </div>
    </div>
    <div class="bg-[#121212] p-6 rounded-2xl border border-white/10 space-y-3">
      <div class="flex justify-between items-center">
        <h4 class="font-bold text-white text-sm">Groupe Généraliste par Défaut</h4>
        <span class="px-2.5 py-1 text-[10px] font-bold bg-[#2A7AE2]/20 text-[#2A7AE2] border border-[#2A7AE2]/30 rounded-full">Défaut</span>
      </div>
      <p class="text-xs text-[#A0A0A0]">Scanners automatiques applicables à tous les secteurs d'activité.</p>
    </div>
  </div>
</div>