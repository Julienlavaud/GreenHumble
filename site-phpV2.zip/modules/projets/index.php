<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-black text-white font-serif">3. Projets & Dossiers Clients</h2>
        <p class="text-xs text-[#A0A0A0]">Gestion des dossiers de portefeuilles clients et grands comptes</p>
      </div>
      <button onclick="alert('Création d\'un nouveau projet')" class="px-4 py-2 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">+ Nouveau Projet</button>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div class="bg-[#121212] p-6 rounded-2xl border border-white/10 space-y-3">
        <div class="flex justify-between items-start">
          <h4 class="font-bold text-white text-base">Grand Compte Retail & Luxe</h4>
          <span class="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">Actif</span>
        </div>
        <p class="text-xs text-[#A0A0A0]">Portefeuille de 12 enseignes de distribution pour audit CSRD & Green Claims.</p>
        <div class="pt-2 flex justify-between items-center text-xs text-[#A0A0A0]">
          <span>4 audits liés</span>
          <button onclick="alert('Ouverture du projet')" class="text-[#2A7AE2] font-bold hover:underline">Gérer le projet →</button>
        </div>
      </div>
    </div>
  </div>
</div>