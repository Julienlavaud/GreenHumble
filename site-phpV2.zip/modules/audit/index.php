<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <!-- En-tête du scanner -->
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
    <div class="space-y-2 text-center md:text-left">
      <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-[#2A7AE2]/20 text-[#2A7AE2] border border-[#2A7AE2]/30 uppercase tracking-widest">
        1. Scanner d'Audit & Directive Green Claims
      </div>
      <h2 class="text-3xl font-black text-white font-serif">Diagnostic de Conforme & Allégations Vertes</h2>
      <p class="text-sm text-[#A0A0A0] max-w-2xl">Analysez instantanément une URL d'entreprise ou un rapport RSE pour détecter le greenwashing, calculer le score de risque et générer le kit de prospection commerciale.</p>
    </div>
    <div class="flex items-center gap-3">
      <button id="print-report-btn" class="flex items-center space-x-1.5 px-4 py-2.5 text-xs font-bold text-white bg-[#1E1E1E] hover:bg-white/10 border border-white/10 rounded-xl transition-colors cursor-pointer shadow-sm">
        <span>🖨️ Exporter PDF</span>
      </button>
    </div>
  </div>

  <!-- Formulaire de saisie URL -->
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <h3 class="text-lg font-bold text-white font-serif flex items-center gap-2">
      <span>🌐 Lancer une nouvelle analyse d'entreprise</span>
    </h3>
    <form id="audit-form" class="space-y-4">
      <div>
        <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-2">URL du site web de l'entreprise ou rapport RSE</label>
        <div class="flex gap-3">
          <input type="url" id="audit-url-input" placeholder="https://entreprise-cible.com" required class="flex-1 bg-[#121212] border border-white/10 rounded-xl px-4 py-3.5 text-white text-sm focus:outline-none focus:border-[#2A7AE2]">
          <button type="submit" class="px-8 py-3.5 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-[#2A7AE2]/20 cursor-pointer whitespace-nowrap">Lancer l'Audit IA</button>
        </div>
      </div>
    </form>
  </div>

  <!-- Aperçu du rapport d'exemple -->
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <div class="flex items-center justify-between border-b border-white/10 pb-4">
      <div>
        <h3 class="text-xl font-bold text-white font-serif">Aperçu du Rapport d'Audit & Scoring</h3>
        <p class="text-xs text-[#A0A0A0]">Dernier audit analysé : EcoClean Solutions SA</p>
      </div>
      <span class="px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold rounded-full">Score : 85 / 100 (Conforme)</span>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="bg-[#121212] p-5 rounded-2xl border border-white/10 space-y-2">
        <span class="text-xs font-bold text-[#A0A0A0] uppercase">Secteur auto-déduit</span>
        <h4 class="text-base font-bold text-white">Énergie & CleanTech</h4>
      </div>
      <div class="bg-[#121212] p-5 rounded-2xl border border-white/10 space-y-2">
        <span class="text-xs font-bold text-[#A0A0A0] uppercase">Effectifs salariés</span>
        <h4 class="text-base font-bold text-white">50 - 250 salariés</h4>
      </div>
      <div class="bg-[#121212] p-5 rounded-2xl border border-white/10 space-y-2">
        <span class="text-xs font-bold text-[#A0A0A0] uppercase">Chiffre d'affaires estimé</span>
        <h4 class="text-base font-bold text-white">15 - 50 M€</h4>
      </div>
    </div>
  </div>
</div>