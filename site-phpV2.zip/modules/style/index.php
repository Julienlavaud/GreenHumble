<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <h2 class="text-2xl font-black text-white font-serif">Style & Charte Graphique</h2>
    <p class="text-xs text-[#A0A0A0]">Gestion des thèmes sombres, couleurs et identité visuelle.</p>
  </div>
</div>