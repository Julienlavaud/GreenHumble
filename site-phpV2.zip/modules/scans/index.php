<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-2xl font-black text-white font-serif">2. Historique & Consultation des Scans</h2>
        <p class="text-xs text-[#A0A0A0]">Retrouvez l'ensemble des audits et rapports générés par l'application</p>
      </div>
      <span class="px-3 py-1 bg-[#2A7AE2]/20 text-[#2A7AE2] border border-[#2A7AE2]/30 text-xs font-bold rounded-full">2 scans enregistrés</span>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-xs text-[#E0E0E0]">
        <thead class="bg-[#121212] text-[#A0A0A0] uppercase font-bold tracking-wider">
          <tr>
            <th class="px-6 py-4">ID Scan</th>
            <th class="px-6 py-4">Entreprise & URL</th>
            <th class="px-6 py-4">Secteur & Effectifs</th>
            <th class="px-6 py-4">Score de Risque</th>
            <th class="px-6 py-4 text-right">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/10">
          <tr class="hover:bg-white/5 transition-colors">
            <td class="px-6 py-4 font-mono font-bold text-white">#SCN-88491</td>
            <td class="px-6 py-4 font-bold text-white">EcoClean Solutions <span class="block text-[10px] text-[#A0A0A0] font-normal">https://ecoclean.fr</span></td>
            <td class="px-6 py-4 text-[#A0A0A0]">Énergie & CleanTech (50-250 sal.)</td>
            <td class="px-6 py-4"><span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">85 / 100 (Conforme)</span></td>
            <td class="px-6 py-4 text-right">
              <button onclick="alert('Ouverture du rapport d\'audit détaillé')" class="px-3 py-1.5 bg-[#2A7AE2] text-white font-bold rounded-lg hover:bg-[#1D5BBF] cursor-pointer">Consulter</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>