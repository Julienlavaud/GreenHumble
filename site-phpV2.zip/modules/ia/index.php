<?php
require_once __DIR__ . '/../../conf/conf.php';
$settingsFile = __DIR__ . '/../../data/ia_settings.json';
$settings = file_exists($settingsFile) ? json_decode(file_get_contents($settingsFile), true) : [
  'model' => 'gemini-3.8-flash',
  'temperature' => 0.2,
  'system_prompt' => 'Expert en audit de greenwashing et conformité directive Green Claims.'
];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['model'] = $_POST['model'] ?? $settings['model'];
    $settings['temperature'] = floatval($_POST['temperature'] ?? $settings['temperature']);
    $settings['system_prompt'] = $_POST['system_prompt'] ?? $settings['system_prompt'];
    if (!file_exists(dirname($settingsFile))) mkdir(dirname($settingsFile), 0755, true);
    file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $success = "Paramètres IA mis à jour avec succès.";
}
?>
<div class="space-y-6">
  <div class="bg-[#1E1E1E] border border-white/10 p-8 rounded-3xl shadow-xl space-y-6">
    <h2 class="text-2xl font-black text-white font-serif">Paramètres du Moteur IA (Gemini 3.8 & Groq)</h2>
    <?php if (isset($success)): ?>
      <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs font-semibold"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="POST" class="space-y-4">
      <div>
        <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Modèle d'IA</label>
        <select name="model" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs">
          <option value="gemini-3.8-flash" <?= $settings['model'] === 'gemini-3.8-flash' ? 'selected' : '' ?>>Gemini 3.8 Flash (Recommandé)</option>
          <option value="gemini-2.5-flash" <?= $settings['model'] === 'gemini-2.5-flash' ? 'selected' : '' ?>>Gemini 2.5 Flash</option>
        </select>
      </div>
      <div>
        <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Température (<?= $settings['temperature'] ?>)</label>
        <input type="range" name="temperature" min="0" max="1" step="0.05" value="<?= $settings['temperature'] ?>" class="w-full accent-[#2A7AE2]">
      </div>
      <div>
        <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Prompt Système</label>
        <textarea name="system_prompt" rows="4" class="w-full bg-[#121212] border border-white/10 rounded-xl p-4 text-white text-xs font-mono"><?= htmlspecialchars($settings['system_prompt']) ?></textarea>
      </div>
      <button type="submit" class="px-6 py-2.5 bg-[#2A7AE2] text-white font-bold text-xs rounded-xl shadow-md cursor-pointer">Enregistrer les modifications</button>
    </form>
  </div>
</div>