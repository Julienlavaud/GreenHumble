<?php
require_once __DIR__ . '/../conf/conf.php';

$page = $_GET['page'] ?? 'audit';
$allowed_pages = ['audit', 'scans', 'projets', 'listes', 'groupes', 'ia', 'collaborateurs', 'style', 'edition', 'sauvegarde'];

if (!in_array($page, $allowed_pages)) {
    $page = 'audit';
}

$isAdminModule = in_array($page, ['ia', 'collaborateurs', 'style', 'edition', 'sauvegarde']);
?>
<!DOCTYPE html>
<html lang="fr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= GH_APP_NAME ?></title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="min-h-screen flex flex-col antialiased selection:bg-[#2A7AE2] selection:text-white">
    <!-- En-tête / Header identique à React -->
    <header class="sticky top-0 z-40 bg-[#121212] text-white shadow-md border-b border-white/10 no-print">
      <div class="max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16 sm:h-18">
          <!-- Logo GreenHumble -->
          <div class="flex items-center space-x-3 cursor-pointer" onclick="window.location.href='?page=audit'">
            <div class="w-9 h-9 rounded-xl bg-[#2A7AE2] flex items-center justify-center text-white font-bold shadow-md">
              <span class="text-lg font-black">G</span>
            </div>
            <div>
              <div class="flex items-center space-x-2">
                <span class="text-xl sm:text-2xl font-black tracking-tight text-white font-serif">GreenHumble</span>
                <span class="hidden xl:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-[#2A7AE2]/20 text-[#2A7AE2] border border-[#2A7AE2]/30 uppercase tracking-widest">admin</span>
              </div>
            </div>
          </div>

          <!-- Onglets Obligatoires du Viewer : 1. Audit, 2. Scans, 3. Projets, 4. Listes de travail, 5. Groupes -->
          <nav class="hidden lg:flex items-center space-x-1 bg-[#1E1E1E] p-1.5 rounded-2xl border border-white/10">
            <a href="?page=audit" class="nav-tab flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all <?= $page === 'audit' ? 'bg-[#2A7AE2] text-white shadow-md' : 'text-[#E0E0E0] hover:text-[#2A7AE2] hover:bg-white/5' ?>" data-page="audit"><span>1. Audit</span></a>
            <a href="?page=scans" class="nav-tab flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all <?= $page === 'scans' ? 'bg-[#2A7AE2] text-white shadow-md' : 'text-[#E0E0E0] hover:text-[#2A7AE2] hover:bg-white/5' ?>" data-page="scans"><span>2. Scans</span></a>
            <a href="?page=projets" class="nav-tab flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all <?= $page === 'projets' ? 'bg-[#2A7AE2] text-white shadow-md' : 'text-[#E0E0E0] hover:text-[#2A7AE2] hover:bg-white/5' ?>" data-page="projets"><span>3. Projets</span></a>
            <a href="?page=listes" class="nav-tab flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all <?= $page === 'listes' ? 'bg-[#2A7AE2] text-white shadow-md' : 'text-[#E0E0E0] hover:text-[#2A7AE2] hover:bg-white/5' ?>" data-page="listes"><span>4. Listes de travail</span></a>
            <a href="?page=groupes" class="nav-tab flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all <?= $page === 'groupes' ? 'bg-[#2A7AE2] text-white shadow-md' : 'text-[#E0E0E0] hover:text-[#2A7AE2] hover:bg-white/5' ?>" data-page="groupes"><span>5. Groupes</span></a>
          </nav>

          <!-- Actions : Admin, Connexion, Déconnexion -->
          <div class="flex items-center space-x-2.5">
            <a href="?page=ia" class="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all bg-[#1E1E1E] text-emerald-400 hover:text-white hover:bg-emerald-600/30 border border-emerald-500/40 shadow-sm">
              <span>Admin</span>
            </a>
            <div class="flex items-center space-x-2 pl-2 border-l border-white/10">
              <div class="w-7 h-7 rounded-lg bg-[#2A7AE2] text-white flex items-center justify-center font-bold text-xs">J</div>
              <span class="text-xs font-semibold text-[#E0E0E0] hidden xl:inline">Julien Lavaud</span>
              <button onclick="alert('Déconnexion réussie')" class="flex items-center space-x-1 px-3 py-1.5 text-xs font-bold text-rose-300 hover:text-white bg-[#1E1E1E] hover:bg-rose-950/60 border border-white/10 hover:border-rose-800 rounded-xl transition-colors cursor-pointer">
                <span>Déconnexion</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Sous-menu Admin si module admin actif -->
    <?php if ($isAdminModule): ?>
    <div class="bg-[#181818] border-b border-white/10 py-3">
      <div class="max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-2 overflow-x-auto text-xs">
        <span class="text-[#A0A0A0] font-bold uppercase tracking-wider mr-2">Console Admin :</span>
        <a href="?page=ia" class="px-3 py-1.5 rounded-xl font-bold transition-all <?= $page === 'ia' ? 'bg-[#2A7AE2] text-white' : 'bg-[#1E1E1E] text-[#E0E0E0] hover:bg-white/5' ?>">1. IA</a>
        <a href="?page=collaborateurs" class="px-3 py-1.5 rounded-xl font-bold transition-all <?= $page === 'collaborateurs' ? 'bg-[#2A7AE2] text-white' : 'bg-[#1E1E1E] text-[#E0E0E0] hover:bg-white/5' ?>">2. Collaborateurs</a>
        <a href="?page=style" class="px-3 py-1.5 rounded-xl font-bold transition-all <?= $page === 'style' ? 'bg-[#2A7AE2] text-white' : 'bg-[#1E1E1E] text-[#E0E0E0] hover:bg-white/5' ?>">3. Style</a>
        <a href="?page=edition" class="px-3 py-1.5 rounded-xl font-bold transition-all <?= $page === 'edition' ? 'bg-[#2A7AE2] text-white' : 'bg-[#1E1E1E] text-[#E0E0E0] hover:bg-white/5' ?>">4. Édition</a>
        <a href="?page=sauvegarde" class="px-3 py-1.5 rounded-xl font-bold transition-all <?= $page === 'sauvegarde' ? 'bg-[#2A7AE2] text-white' : 'bg-[#1E1E1E] text-[#E0E0E0] hover:bg-white/5' ?>">5. Sauvegarde</a>
      </div>
    </div>
    <?php endif; ?>

    <!-- Corps principal -->
    <main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <?php
        $modulePath = __DIR__ . '/../modules/' . $page . '/index.php';
        if (file_exists($modulePath)) {
            include $modulePath;
        } else {
            echo '<div class="text-rose-400 p-6">Module introuvable.</div>';
        }
        ?>
    </main>

    <!-- Pied de page -->
    <footer class="bg-[#121212] border-t border-white/10 py-6 text-center text-xs text-[#A0A0A0]">
        <p><?= GH_APP_NAME ?> — Structure Dolibarr PHP (htdocs/, conf/, modules/, assets/, sql/)</p>
    </footer>

    <script src="../assets/js/app.js"></script>
</body>
</html>