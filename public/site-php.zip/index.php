<?php
header('Location: htdocs/index.php');
exit;
?>