<?php
require_once __DIR__ . '/../../conf/conf.php';
$settingsFile = __DIR__ . '/../../data/ia_settings.json';
$settings = file_exists($settingsFile) ? json_decode(file_get_contents($settingsFile), true) : [
  'model' => 'gemini-3.8-flash',
  'temperature' => 0.2,
  'max_tokens' => 4096,
  'system_prompt' => 'Expert en audit de greenwashing et conformité directive Green Claims.'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['model'] = $_POST['model'] ?? $settings['model'];
    $settings['temperature'] = floatval($_POST['temperature'] ?? $settings['temperature']);
    $settings['system_prompt'] = $_POST['system_prompt'] ?? $settings['system_prompt'];
    if (!file_exists(dirname($settingsFile))) {
        mkdir(dirname($settingsFile), 0755, true);
    }
    file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $success = "Paramètres du Moteur IA mis à jour avec succès.";
}
?>
<div class="space-y-6">
  <div class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h2 class="text-xl font-bold text-white flex items-center gap-2 font-serif">
        <span class="w-2.5 h-2.5 rounded-full bg-[#2A7AE2]"></span>
        Moteur IA & Modèles Gemini
      </h2>
      <p class="text-xs text-[#A0A0A0]">Configuration des modèles d'analyse, températures et prompts système Green Claims</p>
    </div>
  </div>
  <?php if (isset($success)): ?>
    <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs font-semibold"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <form method="POST" class="space-y-4 bg-[#1E1E1E] p-6 rounded-2xl border border-white/10">
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Modèle d'IA principal</label>
      <select name="model" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#2A7AE2]">
        <option value="gemini-3.8-flash" <?= $settings['model'] === 'gemini-3.8-flash' ? 'selected' : '' ?>>Gemini 3.8 Flash (Recommandé - Ultra Rapide)</option>
        <option value="gemini-2.5-flash" <?= $settings['model'] === 'gemini-2.5-flash' ? 'selected' : '' ?>>Gemini 2.5 Flash</option>
        <option value="gemini-2.5-pro" <?= $settings['model'] === 'gemini-2.5-pro' ? 'selected' : '' ?>>Gemini 2.5 Pro</option>
        <option value="groq-llama3" <?= $settings['model'] === 'groq-llama3' ? 'selected' : '' ?>>Groq Llama 3 70B</option>
      </select>
    </div>
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Température (Créativité : <?= $settings['temperature'] ?>)</label>
      <input type="range" name="temperature" min="0" max="1" step="0.05" value="<?= $settings['temperature'] ?>" class="w-full accent-[#2A7AE2]">
    </div>
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Prompt Système (Directive Green Claims)</label>
      <textarea name="system_prompt" rows="5" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#2A7AE2] font-mono"><?= htmlspecialchars($settings['system_prompt']) ?></textarea>
    </div>
    <button type="submit" class="px-5 py-2.5 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">Enregistrer les paramètres IA</button>
  </form>
</div>