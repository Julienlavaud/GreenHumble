<?php
require_once __DIR__ . '/../../conf/conf.php';
?>
<div class="space-y-6">
  <div class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h2 class="text-xl font-bold text-white flex items-center gap-2 font-serif">
        <span class="w-2.5 h-2.5 rounded-full bg-[#2A7AE2]"></span>
        Sauvegarde & Archive Souveraine
      </h2>
      <p class="text-xs text-[#A0A0A0]">Exportation et restauration complète des données de l'application</p>
    </div>
  </div>
  <div class="bg-[#1E1E1E] p-6 rounded-2xl border border-white/10 space-y-4">
    <p class="text-[#E0E0E0] text-xs leading-relaxed">Générez une archive ZIP complète encryptée et structurée de toutes vos données d'audit, projets, listes de travail et paramètres IA pour une portabilité totale sur OVH.</p>
    <a href="?page=sauvegarde&export=1" class="inline-flex items-center gap-2 px-5 py-2.5 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">
      Télécharger l'archive de sauvegarde (.zip)
    </a>
  </div>
</div>