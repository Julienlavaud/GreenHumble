<?php
require_once __DIR__ . '/../../conf/conf.php';
$collabFile = __DIR__ . '/../../data/collaborateurs.json';
$collaborateurs = file_exists($collabFile) ? json_decode(file_get_contents($collabFile), true) : [
  ['id' => 1, 'nom' => 'Julien Lavaud', 'email' => 'jul1lavaud@gmail.com', 'role' => 'Super Admin'],
  ['id' => 2, 'nom' => 'Auditeur ESG', 'email' => 'audit@greenhumble.local', 'role' => 'Analyste Senior']
];
?>
<div class="space-y-6">
  <div class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h2 class="text-xl font-bold text-white flex items-center gap-2 font-serif">
        <span class="w-2.5 h-2.5 rounded-full bg-[#2A7AE2]"></span>
        Collaborateurs & Rôles
      </h2>
      <p class="text-xs text-[#A0A0A0]">Gestion des comptes d'accès, habilitations et rôles de sécurité</p>
    </div>
  </div>
  <div class="bg-[#1E1E1E] rounded-2xl border border-white/10 overflow-hidden">
    <table class="w-full text-left text-xs text-[#E0E0E0]">
      <thead class="bg-[#121212] text-[#A0A0A0] uppercase tracking-wider font-bold">
        <tr>
          <th class="px-6 py-3.5">Nom</th>
          <th class="px-6 py-3.5">Email</th>
          <th class="px-6 py-3.5">Rôle</th>
          <th class="px-6 py-3.5 text-right">Actions</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/10">
        <?php foreach ($collaborateurs as $c): ?>
        <tr class="hover:bg-white/5 transition-colors">
          <td class="px-6 py-4 font-bold text-white"><?= htmlspecialchars($c['nom']) ?></td>
          <td class="px-6 py-4 text-[#A0A0A0]"><?= htmlspecialchars($c['email']) ?></td>
          <td class="px-6 py-4"><span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#2A7AE2]/20 text-[#2A7AE2] border border-[#2A7AE2]/30"><?= htmlspecialchars($c['role']) ?></span></td>
          <td class="px-6 py-4 text-right">
            <button class="text-[#A0A0A0] hover:text-white font-bold cursor-pointer">Modifier</button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>