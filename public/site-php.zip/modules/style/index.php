<?php
require_once __DIR__ . '/../../conf/conf.php';
$styleFile = __DIR__ . '/../../data/style.json';
$style = file_exists($styleFile) ? json_decode(file_get_contents($styleFile), true) : [
  'theme' => 'dark',
  'primary_color' => '#2A7AE2',
  'slogan' => 'Audit Greenwashing & Directive Green Claims'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $style['slogan'] = $_POST['slogan'] ?? $style['slogan'];
    $style['primary_color'] = $_POST['primary_color'] ?? $style['primary_color'];
    if (!file_exists(dirname($styleFile))) {
        mkdir(dirname($styleFile), 0755, true);
    }
    file_put_contents($styleFile, json_encode($style, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $success = "Style et charte graphique mis à jour avec succès.";
}
?>
<div class="space-y-6">
  <div class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h2 class="text-xl font-bold text-white flex items-center gap-2 font-serif">
        <span class="w-2.5 h-2.5 rounded-full bg-[#2A7AE2]"></span>
        Style & Thème Graphique
      </h2>
      <p class="text-xs text-[#A0A0A0]">Personnalisation des thèmes, couleurs et slogans institutionnels</p>
    </div>
  </div>
  <?php if (isset($success)): ?>
    <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs font-semibold"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <form method="POST" class="space-y-4 bg-[#1E1E1E] p-6 rounded-2xl border border-white/10">
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Slogan Principal</label>
      <input type="text" name="slogan" value="<?= htmlspecialchars($style['slogan']) ?>" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#2A7AE2]">
    </div>
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Couleur d'accentuation principale</label>
      <div class="flex items-center gap-3">
        <input type="color" name="primary_color" value="<?= htmlspecialchars($style['primary_color']) ?>" class="w-12 h-12 rounded-xl bg-[#121212] border border-white/10 cursor-pointer">
        <span class="font-mono text-xs text-[#E0E0E0]"><?= htmlspecialchars($style['primary_color']) ?></span>
      </div>
    </div>
    <button type="submit" class="px-5 py-2.5 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">Enregistrer le style</button>
  </form>
</div>