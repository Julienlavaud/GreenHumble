<?php
require_once __DIR__ . '/../../conf/conf.php';
$textsFile = __DIR__ . '/../../data/texts.json';
$texts = file_exists($textsFile) ? json_decode(file_get_contents($textsFile), true) : [
  'header_title' => 'GreenHumble Enterprise',
  'footer_copy' => '© 2026 GreenHumble — Tous droits réservés'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $texts['header_title'] = $_POST['header_title'] ?? $texts['header_title'];
    $texts['footer_copy'] = $_POST['footer_copy'] ?? $texts['footer_copy'];
    if (!file_exists(dirname($textsFile))) {
        mkdir(dirname($textsFile), 0755, true);
    }
    file_put_contents($textsFile, json_encode($texts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $success = "Textes et libellés mis à jour avec succès.";
}
?>
<div class="space-y-6">
  <div class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h2 class="text-xl font-bold text-white flex items-center gap-2 font-serif">
        <span class="w-2.5 h-2.5 rounded-full bg-[#2A7AE2]"></span>
        Édition des Textes & Libellés
      </h2>
      <p class="text-xs text-[#A0A0A0]">Modification dynamique des accroches et contenus textuels de l'application</p>
    </div>
  </div>
  <?php if (isset($success)): ?>
    <div class="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs font-semibold"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <form method="POST" class="space-y-4 bg-[#1E1E1E] p-6 rounded-2xl border border-white/10">
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Titre de l'en-tête</label>
      <input type="text" name="header_title" value="<?= htmlspecialchars($texts['header_title']) ?>" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#2A7AE2]">
    </div>
    <div>
      <label class="block text-xs font-bold text-[#A0A0A0] uppercase mb-1.5">Mention du pied de page</label>
      <input type="text" name="footer_copy" value="<?= htmlspecialchars($texts['footer_copy']) ?>" class="w-full bg-[#121212] border border-white/10 rounded-xl px-4 py-2.5 text-white text-xs focus:outline-none focus:border-[#2A7AE2]">
    </div>
    <button type="submit" class="px-5 py-2.5 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer">Enregistrer les textes</button>
  </form>
</div>