<?php
/**
 * GreenHumble v1.0 — Endpoint API Prospection B2B
 * /api/prospec.php
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/app_state.php';
require_once __DIR__ . '/includes/ai_engine.php';
require_once __DIR__ . '/includes/scans_manager.php';

$rawInput = file_get_contents('php://input');
$inputData = json_decode($rawInput, true) ?: $_POST;
$method = $_SERVER['REQUEST_METHOD'];

// HTML Browser GET Request -> Redirection vers Audit.php (Redondance supprimée)
$acceptHeader = $_SERVER['HTTP_ACCEPT'] ?? '';
$isHtmlRequest = (strpos($acceptHeader, 'text/html') !== false || isset($_GET['view'])) && $method === 'GET' && empty($_GET['url']);

if ($isHtmlRequest) {
    header('Location: /api/audit.php');
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS');

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$url = trim($inputData['url'] ?? $_GET['url'] ?? '');

if (empty($url)) {
    http_response_code(400);
    echo json_encode([
        'error' => 'URL manquante ou invalide pour le module prospection.',
        'usage' => 'POST /api/prospec {"url": "https://prospect-entreprise.fr"}'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!preg_match('/^https?:\/\//i', $url)) {
    $url = 'https://' . $url;
}

// Analyse IA
$aiResult = analyze_url_with_ai($url);
$resultData = is_array($aiResult) ? $aiResult : json_decode($aiResult, true);

if (!$resultData) {
    $resultData = [
        'url' => $url,
        'summary' => 'Analyse Prospection B2B effectuée.',
        'prospection' => [
            'scoreProspect' => 4,
            'signauxFaibles' => ['Allégations RSE à vérifier', 'Risque d\'exposition réglementaire'],
            'besoinsPotentiels' => ['Audit EmpCO & Green Claims', 'Bilan Carbone Scopes 1-2-3'],
            'recommandation' => 'Engager un premier contact de sensibilisation.',
            'messageApproche' => "Bonjour, nous avons identifié des axes d'optimisation RSE majeurs pour $url."
        ]
    ];
}

// Enregistrement dans la base de données unifiée des scans (type pipeline)
$recordedScan = record_scan($url, 'pipeline', $resultData, $inputData['group_id'] ?? 'grp_widget_default', 'admin', 'termine');

echo json_encode([
    'success' => true,
    'message' => 'Analyse prospection effectuée et enregistrée.',
    'scan' => $recordedScan,
    'data' => $resultData
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;
