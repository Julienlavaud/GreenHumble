<?php
/**
 * GreenHumble v1.0 — Endpoint REST & Page HTML Officiels /api/audit
 * Supporte :
 *  - GET  /api/audit : Page HTML interactive en navigateur, ou JSON si Accept: application/json
 *  - POST /api/audit : Exécute une analyse IA anti-greenwashing complète et sauvegarde le résultat
 *  - DELETE /api/audit : Supprime un audit de l'historique
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/app_state.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/ai_engine.php';

$storageFile = __DIR__ . '/../data/stored_audits.json';

// Helper de lecture des audits
function get_stored_audits($file) {
    if (!file_exists($file)) {
        return [];
    }
    $content = file_get_contents($file);
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

// Helper d'écriture des audits
function save_stored_audits($file, $audits) {
    file_put_contents($file, json_encode($audits, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$method = $_SERVER['REQUEST_METHOD'];
$acceptHeader = $_SERVER['HTTP_ACCEPT'] ?? '';
$isHtmlRequest = (strpos($acceptHeader, 'text/html') !== false || isset($_GET['view'])) && !isset($_GET['json']) && $method === 'GET' && empty($_GET['url']) && empty($_GET['id']);

if (!$isHtmlRequest) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
    if ($method === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

if ($method === 'GET') {
    $audits = get_stored_audits($storageFile);
    $urlQuery = trim($_GET['url'] ?? '');
    $idQuery = trim($_GET['id'] ?? '');

    if (!empty($idQuery)) {
        foreach ($audits as $item) {
            if (($item['id'] ?? '') === $idQuery) {
                echo json_encode($item, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
        http_response_code(404);
        echo json_encode(['error' => 'Audit non trouvé pour l\'ID spécifié.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!empty($urlQuery)) {
        if (!preg_match('/^https?:\/\//i', $urlQuery)) {
            $urlQuery = 'https://' . $urlQuery;
        }
        $aiResult = analyze_url_with_ai($urlQuery);
        $resultData = is_array($aiResult) ? $aiResult : json_decode($aiResult, true);
        echo json_encode($resultData ?: ['raw' => $aiResult], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($isHtmlRequest) {
        $page_title = "Audit RSE & Diagnostic Green Claims — GreenHumble";
        include __DIR__ . '/includes/header.php';
        ?>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 bg-[#121212] text-[#E0E0E0]">
            <!-- Hero Card -->
            <div class="bg-[#1E1E1E] text-white rounded-2xl p-6 sm:p-8 shadow-lg border border-white/10">
                <div class="max-w-3xl">
                    <span class="px-3 py-1 bg-[#2A7AE2]/20 text-[#2A7AE2] rounded-lg text-xs font-semibold uppercase tracking-wider border border-[#2A7AE2]/30">
                        Module Audit RSE & Prospection Intégrée
                    </span>
                    <h1 class="text-2xl sm:text-3xl font-bold mt-3 tracking-tight text-white">Audit RSE, Diagnostic & Prospection</h1>
                    <p class="mt-2 text-[#AAAAAA] text-xs sm:text-sm leading-relaxed">
                        Exécutez des audits de conformité environnementale en direct. Les résultats (diagnostic, allégations, opportunités de prospection) sont sauvegardés dans la base unique.
                    </p>
                </div>

                <!-- Formulaire de lancement -->
                <form id="auditFormPage" onsubmit="handleAuditSubmit(event)" class="mt-6 flex flex-col sm:flex-row gap-3">
                    <input type="text" id="auditUrlInput" required placeholder="https://votre-entreprise.fr ou site.com" class="flex-grow px-4 py-3 bg-[#121212] text-white border border-white/15 rounded-xl text-sm font-medium focus:border-[#2A7AE2] focus:outline-none">
                    <button type="submit" id="auditSubmitBtn" class="px-6 py-3 bg-[#2A7AE2] hover:bg-[#1D5BBF] text-white font-semibold rounded-xl transition-colors border-none cursor-pointer flex items-center justify-center gap-2">
                        <span>Lancer l'audit & prospection</span>
                    </button>
                </form>
            </div>

            <!-- Liste des Audits sous forme de Cartes sobres -->
            <div class="space-y-4">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-bold text-white">Audits & Diagnostics Enregistrés (<?php echo count($audits); ?>)</h2>
                    <span class="text-xs text-[#AAAAAA]">Enregistrement unifié /data/scans.json</span>
                </div>

                <div id="auditsCardsGrid" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php if (empty($audits)): ?>
                        <div class="col-span-full bg-[#1E1E1E] p-8 text-center text-[#AAAAAA] text-sm rounded-2xl border border-white/10">
                            Aucun audit enregistré. Saisissez une URL ci-dessus pour lancer le premier diagnostic.
                        </div>
                    <?php else: ?>
                        <?php foreach ($audits as $item): 
                            $targetUrl = $item['targetUrl'] ?? $item['url'] ?? 'Site Web';
                            $score = $item['score'] ?? $item['riskScore'] ?? 50;
                            $riskLevel = $item['riskLevel'] ?? ($score < 40 ? 'critique' : ($score < 60 ? 'eleve' : ($score < 75 ? 'modere' : 'faible')));
                            $summary = $item['summary'] ?? 'Analyse de conformité RSE effectuée.';
                            $claims = $item['claims'] ?? $item['detectedClaims'] ?? [];
                            $prospec = $item['prospection'] ?? null;
                            ?>
                            <div class="bg-[#1E1E1E] p-6 rounded-2xl border border-white/10 shadow-lg space-y-4 flex flex-col justify-between">
                                <div class="space-y-3">
                                    <div class="flex items-start justify-between gap-4">
                                        <div>
                                            <span class="text-xs text-[#AAAAAA] font-mono">ID: <?php echo htmlspecialchars($item['id'] ?? 'aud_0'); ?></span>
                                            <h3 class="text-lg font-bold text-[#2A7AE2] truncate max-w-xs sm:max-w-sm mt-0.5"><?php echo htmlspecialchars($targetUrl); ?></h3>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-2xl font-bold <?php echo $score >= 75 ? 'text-emerald-400' : ($score >= 50 ? 'text-amber-400' : 'text-rose-400'); ?>">
                                                <?php echo $score; ?> / 100
                                            </div>
                                            <span class="px-2.5 py-0.5 rounded-md text-xs font-semibold <?php echo $riskLevel === 'faible' ? 'bg-emerald-500/20 text-emerald-400' : ($riskLevel === 'modere' ? 'bg-amber-500/20 text-amber-400' : 'bg-rose-500/20 text-rose-400'); ?>">
                                                Risque <?php echo htmlspecialchars($riskLevel); ?>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="text-xs text-[#E0E0E0] leading-relaxed bg-[#121212] p-3.5 rounded-xl border border-white/5">
                                        <strong class="text-white block mb-1">Résumé Diagnostic :</strong>
                                        <?php echo htmlspecialchars($summary); ?>
                                    </div>

                                    <?php if (!empty($claims)): ?>
                                        <div class="space-y-1.5 pt-1">
                                            <span class="text-xs font-semibold text-white block">Recommandations & allégations (<?php echo count($claims); ?>) :</span>
                                            <?php foreach (array_slice($claims, 0, 2) as $c): ?>
                                                <div class="text-xs p-2.5 bg-rose-900/20 border border-rose-500/30 rounded-xl text-[#E0E0E0] space-y-0.5">
                                                    <div class="font-semibold text-rose-300">
                                                        <?php echo htmlspecialchars($c['term'] ?? 'Allégation'); ?>
                                                    </div>
                                                    <?php if (!empty($c['correctionNote'])): ?>
                                                        <div class="text-[11px] text-[#AAAAAA]"><?php echo htmlspecialchars($c['correctionNote']); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- CARTE PROSPECTION INTÉGRÉE -->
                                    <?php if (!empty($prospec)): ?>
                                        <div class="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl space-y-2">
                                            <div class="flex items-center justify-between">
                                                <span class="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                                                    <span>💼</span> Carte Prospection B2B
                                                </span>
                                                <span class="text-[11px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded font-semibold">
                                                    Potentiel <?php echo htmlspecialchars($prospec['scoreProspect'] ?? 4); ?>/5
                                                </span>
                                            </div>
                                            <?php if (!empty($prospec['recommandation'])): ?>
                                                <p class="text-xs text-[#E0E0E0]">
                                                    <strong class="text-emerald-300">Recommandation :</strong> <?php echo htmlspecialchars($prospec['recommandation']); ?>
                                                </p>
                                            <?php endif; ?>
                                            <?php if (!empty($prospec['messageApproche'])): ?>
                                                <div class="text-[11px] text-[#AAAAAA] italic bg-[#121212] p-2.5 rounded-lg border border-white/5">
                                                    « <?php echo htmlspecialchars($prospec['messageApproche']); ?> »
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                                    <span class="text-[#AAAAAA]"><?php echo date('d/m/Y H:i', strtotime($item['createdAt'] ?? 'now')); ?></span>
                                    <button onclick="deleteAuditCard('<?php echo htmlspecialchars($item['id'] ?? ''); ?>')" class="text-xs text-rose-400 hover:text-rose-300 font-semibold bg-transparent border-none p-0 cursor-pointer">
                                        Supprimer
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <script>
        async function handleAuditSubmit(e) {
            e.preventDefault();
            const input = document.getElementById('auditUrlInput');
            const btn = document.getElementById('auditSubmitBtn');
            const url = input.value.trim();
            if (!url) return;

            btn.disabled = true;
            btn.textContent = 'Analyse en cours...';

            try {
                const res = await fetch('/api/audit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url: url })
                });
                const data = await res.json();
                if (data.error) {
                    alert('Erreur : ' + data.error);
                } else {
                    location.reload();
                }
            } catch (err) {
                alert('Erreur réseau lors de la création de l\'audit');
            } finally {
                btn.disabled = false;
                btn.textContent = 'Lancer l\'Audit IA';
            }
        }

        async function deleteAuditCard(id) {
            if (!id || !confirm('Voulez-vous vraiment supprimer cet audit ?')) return;
            try {
                const res = await fetch('/api/audit', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                });
                const data = await res.json();
                if (data.success) {
                    location.reload();
                } else {
                    alert('Erreur : ' + (data.error || 'Impossible de supprimer'));
                }
            } catch (err) {
                alert('Erreur réseau');
            }
        }
        </script>
        <?php
        include __DIR__ . '/includes/footer.php';
        exit;
    }

    echo json_encode([
        'total' => count($audits),
        'audits' => $audits
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    $inputData = json_decode($rawInput, true) ?: $_POST;

    $url = trim($inputData['url'] ?? $_GET['url'] ?? '');

    if (empty($url)) {
        http_response_code(400);
        echo json_encode([
            'error' => 'URL manquante ou invalide dans le corps de la requête POST.',
            'usage' => 'POST /api/audit {"url": "https://entreprise-exemple.fr"}'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!preg_match('/^https?:\/\//i', $url)) {
        $url = 'https://' . $url;
    }

    $scanVars = $inputData['scanVars'] ?? [];
    $csrDocumentText = $inputData['csrDocumentText'] ?? null;
    $customPrompt = $inputData['customPrompt'] ?? null;

    $aiResult = analyze_url_with_ai($url, $customPrompt, $csrDocumentText);
    $resultData = is_array($aiResult) ? $aiResult : json_decode($aiResult, true);

    if (!$resultData) {
        $resultData = [
            'url' => $url,
            'rawAnalysis' => $aiResult,
            'riskScore' => 50,
            'riskLevel' => 'modere'
        ];
    }

    $auditId = 'aud_' . date('Ymd_His') . '_' . substr(md5($url), 0, 6);
    $resultData['id'] = $auditId;
    $resultData['createdAt'] = date('c');
    $resultData['targetUrl'] = $url;

    $audits = get_stored_audits($storageFile);
    array_unshift($audits, $resultData);
    $audits = array_slice($audits, 0, 50);
    save_stored_audits($storageFile, $audits);

    // Enregistrement dans la base unifiée des scans
    try {
        require_once __DIR__ . '/includes/scans_manager.php';
        record_scan($url, 'diagnostic', $resultData, $inputData['group_id'] ?? 'grp_widget_default', 'admin', 'termine');
    } catch (Exception $e) {}

    // Enregistrement officiel en base de données OVH MySQL (cl_companies & cl_audits)
    try {
        $db = get_db_connection();
        ensure_db_schema($db);

        $hostClean = parse_url($url, PHP_URL_HOST);
        if (!$hostClean) $hostClean = preg_replace('#^https?://#', '', $url);
        $hostClean = strtolower(preg_replace('/^www\./', '', $hostClean));

        $headcount = trim($inputData['headcount'] ?? $resultData['headcount'] ?? '25 salariés (10-49)');
        $turnover = trim($inputData['turnover'] ?? $resultData['turnover'] ?? '4.5 M€');
        $sector = trim($inputData['sector'] ?? $resultData['sector'] ?? 'Services & Conseil B2B');
        $domainParts = explode('.', $hostClean);
        $companyName = trim($inputData['companyName'] ?? $resultData['companyName'] ?? ucfirst($domainParts[0]));

        $stmtFindComp = $db->prepare("SELECT id FROM cl_companies WHERE clean_url = ? OR website LIKE ? LIMIT 1");
        $stmtFindComp->execute([$hostClean, "%{$hostClean}%"]);
        $existingCompId = $stmtFindComp->fetchColumn();

        if ($existingCompId) {
            $companyId = $existingCompId;
            $stmtUpdateComp = $db->prepare("UPDATE cl_companies SET sector = COALESCE(NULLIF(?, ''), sector), headcount = COALESCE(NULLIF(?, ''), headcount), turnover = COALESCE(NULLIF(?, ''), turnover) WHERE id = ?");
            $stmtUpdateComp->execute([$sector, $headcount, $turnover, $companyId]);
        } else {
            $stmtInsertComp = $db->prepare("INSERT INTO cl_companies (name, clean_url, website, sector, headcount, turnover) VALUES (?, ?, ?, ?, ?, ?)");
            $stmtInsertComp->execute([$companyName, $hostClean, $url, $sector, $headcount, $turnover]);
            $companyId = $db->lastInsertId();
        }

        $score = $resultData['score'] ?? $resultData['riskScore'] ?? 50;
        $riskLevel = $resultData['riskLevel'] ?? ($score < 40 ? 'critique' : ($score < 60 ? 'eleve' : ($score < 75 ? 'modere' : 'faible')));
        $summary = $resultData['summary'] ?? ($resultData['clientSummary']['headline'] ?? 'Audit anti-greenwashing GreenHumble');
        $bannedCount = count($resultData['claims'] ?? $resultData['detectedClaims'] ?? []);

        $stmtInsertAudit = $db->prepare("INSERT INTO cl_audits (company_id, url, clean_url, score, riskLevel, totalBannedWordsDetected, summary, headcount, turnover, status, raw_result_json, analyzedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scan_termine', ?, NOW())");
        $stmtInsertAudit->execute([
            $companyId,
            $url,
            $hostClean,
            $score,
            $riskLevel,
            $bannedCount,
            $summary,
            $headcount,
            $turnover,
            json_encode($resultData, JSON_UNESCAPED_UNICODE)
        ]);
        $insertedDbId = $db->lastInsertId();
        $resultData['db_id'] = $insertedDbId;
        $resultData['headcount'] = $headcount;
        $resultData['turnover'] = $turnover;
        $resultData['sector'] = $sector;
    } catch (\Throwable $e) {
        error_log("Erreur enregistrement DB audit: " . $e->getMessage());
    }

    echo json_encode($resultData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'DELETE') {
    $rawInput = file_get_contents('php://input');
    $inputData = json_decode($rawInput, true) ?: $_GET;
    $idToDelete = trim($inputData['id'] ?? '');

    if (empty($idToDelete)) {
        http_response_code(400);
        echo json_encode(['error' => 'ID d\'audit manquant pour la suppression.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $audits = get_stored_audits($storageFile);
    $filtered = array_values(array_filter($audits, function($item) use ($idToDelete) {
        return ($item['id'] ?? '') !== $idToDelete;
    }));

    save_stored_audits($storageFile, $filtered);
    echo json_encode(['success' => true, 'message' => "Audit {$idToDelete} supprimé avec succès."], JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Méthode HTTP non autorisée.'], JSON_UNESCAPED_UNICODE);
exit;
