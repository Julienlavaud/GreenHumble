<?php
/**
 * GreenHumble v1.0 — Module de Gestion des Groupes de Scanners
 * /api/includes/scanner_groups.php
 */

define('DEFAULT_GROUP_ID', 'grp_widget_default');
define('DEFAULT_GROUP_NAME', 'scanner widget');

function get_groups_file_path() {
    $p1 = __DIR__ . '/../../data/scanner_groups.json';
    $p2 = __DIR__ . '/../data/scanner_groups.json';
    if (file_exists(dirname($p1)) && is_writable(dirname($p1))) {
        return $p1;
    }
    return $p2;
}

function get_scanners_file_path() {
    $p1 = __DIR__ . '/../../data/scanners.json';
    $p2 = __DIR__ . '/../data/scanners.json';
    if (file_exists(dirname($p1)) && is_writable(dirname($p1))) {
        return $p1;
    }
    return $p2;
}

function load_scanner_groups() {
    $file = get_groups_file_path();
    $groups = [];
    if (file_exists($file)) {
        $raw = file_get_contents($file);
        $groups = json_decode($raw, true) ?: [];
    }

    // Ensure default group "scanner widget" exists
    $hasDefault = false;
    foreach ($groups as $g) {
        if (($g['id'] ?? '') === DEFAULT_GROUP_ID || strtolower($g['nom'] ?? '') === strtolower(DEFAULT_GROUP_NAME)) {
            $hasDefault = true;
            break;
        }
    }

    if (!$hasDefault) {
        array_unshift($groups, [
            'id' => DEFAULT_GROUP_ID,
            'nom' => DEFAULT_GROUP_NAME,
            'description' => 'Groupe système par défaut pour les scanners widgets d\'audit.',
            'date_creation' => date('c'),
            'is_default' => true
        ]);
        save_scanner_groups($groups);
    }

    return $groups;
}

function save_scanner_groups($groups) {
    $p1 = __DIR__ . '/../../data/scanner_groups.json';
    $p2 = __DIR__ . '/../data/scanner_groups.json';
    $json = json_encode(array_values($groups), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    @file_put_contents($p1, $json);
    @file_put_contents($p2, $json);
}

function load_scanners() {
    $file = get_scanners_file_path();
    $scanners = [];
    if (file_exists($file)) {
        $raw = file_get_contents($file);
        $scanners = json_decode($raw, true) ?: [];
    }

    // Default scanners fallback if empty
    if (empty($scanners)) {
        $scanners = [
            [
                'id' => 'scn_widget_1',
                'nom' => 'Scanner Widget Public',
                'description' => 'Scanner d\'allégations RSE intégré sur les sites clients et landings.',
                'group_id' => DEFAULT_GROUP_ID,
                'type' => 'widget',
                'status' => 'actif'
            ],
            [
                'id' => 'scn_audit_pro_1',
                'nom' => 'Scanner Audit Pro CSRD',
                'description' => 'Scanner complet de conformité aux critères CSRD et Green Claims.',
                'group_id' => DEFAULT_GROUP_ID,
                'type' => 'audit_pro',
                'status' => 'actif'
            ],
            [
                'id' => 'scn_green_claims_1',
                'nom' => 'Scanner Directive Green Claims UE',
                'description' => 'Scanner automatisé d\'allégations environnementales et de greenwashing.',
                'group_id' => DEFAULT_GROUP_ID,
                'type' => 'green_claims',
                'status' => 'actif'
            ]
        ];
        save_scanners($scanners);
    }

    return $scanners;
}

function save_scanners($scanners) {
    $p1 = __DIR__ . '/../../data/scanners.json';
    $p2 = __DIR__ . '/../data/scanners.json';
    $json = json_encode(array_values($scanners), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    @file_put_contents($p1, $json);
    @file_put_contents($p2, $json);
}
