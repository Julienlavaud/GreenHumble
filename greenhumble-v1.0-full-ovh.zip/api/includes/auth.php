<?php
// /api/includes/auth.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']) || isset($_SESSION['admin_logged_in']);
}

function current_user() {
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? 'Invité',
        'email' => $_SESSION['email'] ?? '',
        'role' => $_SESSION['role'] ?? (isset($_SESSION['admin_logged_in']) ? 'admin' : 'visiteur')
    ];
}

function require_login($required_role = null) {
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_logged_in'])) {
        header('Location: /api/login.php');
        exit;
    }
    
    if ($required_role === 'admin') {
        $userRole = $_SESSION['role'] ?? (isset($_SESSION['admin_logged_in']) ? 'admin' : '');
        if ($userRole !== 'admin' && !isset($_SESSION['admin_logged_in'])) {
            header('Location: /api/admin/index.php');
            exit;
        }
    }
}
