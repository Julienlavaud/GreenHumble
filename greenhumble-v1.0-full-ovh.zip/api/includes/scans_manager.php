<?php
/**
 * GreenHumble v1.0 — Module de Gestion Centralisée des Scans (Diagnostic, Pipeline, Widget)
 * /api/includes/scans_manager.php
 */

require_once __DIR__ . '/scanner_groups.php';
require_once __DIR__ . '/dossiers_manager.php';

function get_scans_file_path() {
    $p1 = __DIR__ . '/../../data/scans.json';
    $p2 = __DIR__ . '/../data/scans.json';
    if (file_exists(dirname($p1)) && is_writable(dirname($p1))) {
        return $p1;
    }
    return $p2;
}

function load_all_scans() {
    $file = get_scans_file_path();
    $scans = [];
    if (file_exists($file)) {
        $raw = file_get_contents($file);
        $scans = json_decode($raw, true) ?: [];
    }
    return $scans;
}

function save_all_scans($scans) {
    $p1 = __DIR__ . '/../../data/scans.json';
    $p2 = __DIR__ . '/../data/scans.json';
    $json = json_encode(array_values($scans), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    @file_put_contents($p1, $json);
    @file_put_contents($p2, $json);
}

function record_scan($url, $type_scan = 'diagnostic', $resultat_ia = null, $group_id = 'grp_widget_default', $utilisateur = 'admin', $statut = 'termine') {
    $scans = load_all_scans();

    $parsedResult = $resultat_ia;
    if (is_string($resultat_ia)) {
        $decoded = json_decode($resultat_ia, true);
        if ($decoded) {
            $parsedResult = $decoded;
        }
    }

    $scanId = 'scan_' . uniqid();

    // Recherche / création automatique du dossier associé
    $dossier = find_or_create_dossier_for_domain($url, $scanId);
    $projectId = $dossier['id'] ?? null;

    $newScan = [
        'id' => $scanId,
        'url' => $url,
        'type_scan' => in_array($type_scan, ['diagnostic', 'pipeline', 'widget']) ? $type_scan : 'diagnostic',
        'group_id' => $group_id ?: 'grp_widget_default',
        'project_id' => $projectId,
        'date_scan' => date('c'),
        'resultat_ia' => $parsedResult ?: ['score' => 60, 'summary' => 'Scan enregistré'],
        'statut' => $statut,
        'utilisateur' => $utilisateur
    ];

    array_unshift($scans, $newScan);
    save_all_scans($scans);

    return $newScan;
}
