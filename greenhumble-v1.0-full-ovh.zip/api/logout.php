<?php
// /api/logout.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION = [];
session_destroy();
header('Location: /api/index.php');
exit;
