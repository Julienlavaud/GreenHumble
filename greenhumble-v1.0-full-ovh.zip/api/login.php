<?php
// /api/login.php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/db.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (!empty($email) && !empty($password)) {
        try {
            $db = get_db_connection();
            $stmt = $db->prepare("SELECT * FROM cl_users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['team_id'] = $user['team_id'];
                if ($user['role'] === 'admin') {
                    $_SESSION['admin_logged_in'] = true;
                }
                
                header('Location: /api/scan.php');
                exit;
            } else {
                $error = "Identifiants invalides (email ou mot de passe incorrect).";
            }
        } catch (Exception $e) {
            $error = "Erreur de base de données : " . $e->getMessage();
        }
    } else {
        $error = "Veuillez remplir tous les champs.";
    }
}

$page_title = "Connexion Espace Collaborateur";
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-md mx-auto my-16 px-4">
    <div class="bg-white p-8 rounded-3xl border border-slate-200 shadow-lg">
        <div class="text-center mb-6">
            <div class="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 font-black text-xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                🔐
            </div>
            <h1 class="text-2xl font-black text-slate-900">Espace Collaborateur</h1>
            <p class="text-xs text-slate-500 mt-1">Accédez à votre console de travail et à vos audits</p>
        </div>

        <?php if ($error): ?>
            <div class="mb-5 p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-medium flex items-center space-x-2">
                <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="/api/login.php" class="space-y-4">
            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Adresse Email</label>
                <input type="email" name="email" required placeholder="collaborateur@climatlocal.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Mot de passe</label>
                <input type="password" name="password" required placeholder="••••••••" class="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <button type="submit" class="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-bold rounded-xl text-sm shadow-md transition-all">
                Se connecter
            </button>
        </form>

        <div class="mt-6 pt-6 border-t border-slate-100 text-center">
            <p class="text-xs text-slate-400">Pas encore de compte ?</p>
            <p class="text-xs text-slate-500 mt-1">Demandez à votre administrateur de vous créer un profil dans la <a href="/api/admin/users.php" class="text-emerald-700 font-bold hover:underline">Console Admin</a>.</p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
